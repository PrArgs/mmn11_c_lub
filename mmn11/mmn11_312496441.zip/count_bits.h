#include <stdio.h>
#include <stdlib.h>

int count_bits(unsigned long value);
void to_binary(unsigned long value);
