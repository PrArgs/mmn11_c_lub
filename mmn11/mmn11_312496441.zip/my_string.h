#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int my_strcmp(char *s,char *t);
int my_strncmp(char *s,char *t,int n);
int my_strchr(char *s, int c);
